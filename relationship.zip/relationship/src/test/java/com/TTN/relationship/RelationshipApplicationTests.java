package com.TTN.relationship;

import com.TTN.relationship.entity.Address;
import com.TTN.relationship.entity.Author;
import com.TTN.relationship.entity.Book;
import com.TTN.relationship.entity.Subject;
import com.TTN.relationship.repository.BookRepository;
import com.TTN.relationship.repository.Repository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@AutoConfigureTestEntityManager
class RelationshipApplicationTests {


	@Autowired
	Repository repository;

	@Autowired
	BookRepository bookRepository;

	@Test
	void contextLoads() {
	}

	//Introduce a List of subjects for author.
	@Test
	public void testCreateAuthor() {
		ArrayList<Subject> list = new ArrayList<>();
		list.add(new Subject("sciene"));
		list.add(new Subject("dsa"));
		list.add(new Subject("algorithm"));

		Author author = new Author();
		author.setId(3);
		author.setAuthorname("Muskanlama");


		Address address = new Address();
		address.setStreetNumber(67);
		address.setLocation("Noida");
		address.setState("UP");

		//saving embedded in our table
		author.setSubjectlist(list);
		author.setAddress(address);

		repository.save(author);
	}


	/*
	//one to one mapping
	//Implement One to One mapping between Author and Book.
	@Test
	public void testOneToOneCreateBook() {
		Book book = new Book();
		book.setId(21);
		book.setBookname("Java");

		Author author = new Author();
		author.setId(211);
		author.setAuthorname("Muskan");

		Address address1 = new Address();
		address1.setStreetNumber(66);
		address1.setLocation("Noida");
		address1.setState("UP");

		//saving embedded in our table
		author.setAddress(address1);


		book.setAuthor(author);
		bookRepository.save(book);


	}

	 */


	/*//one to many
	@Test
	public void testOnetoMany() {
		Author author = new Author();
		author.setId(123);
		author.setAuthorname("Lama");

		Address address2 = new Address();
		address2.setStreetNumber(64);
		address2.setLocation("Bihar");
		address2.setState("UP");

		//saving embedded in our table
		author.setAddress(address2);

		Set<Book> books = new HashSet<Book>();
		Book book=new Book();
		book.setId(10);
		book.setBookname("C++");

		books.add(book);

		author.setBooks(books);

		repository.save(author);

	}

	 */



	//Implement Many to Many Mapping between Author and Book.
	@Test
	public void testManyToMany()
	{
		Author author=new Author();
		author.setId(123);
		author.setAuthorname("Sofi");

		Address address3 = new Address();
		address3.setStreetNumber(68);
		address3.setLocation("haridwar");
		address3.setState("Uk");

		//saving embedded in our table
		author.setAddress(address3);


		Set<Book> books1 = new HashSet<Book>();
		Book book4=new Book();
		book4.setId(23);
		book4.setBookname("C#");
		books1.add(book4);



	   author.setBook(books1);

       repository.save(author);


	}










}
