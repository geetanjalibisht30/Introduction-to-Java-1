package com.TTN.relationship.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "author")
public class Author {



    @Id
    private int id;
    private String authorname;

/*
    //FOR ONE TO ONE MAPPING
    @OneToOne(mappedBy = "author")
    private Book book;

 */

   //one to many
    //bidirectional as we  used many to one in the book entity
    //unidirectional when we don't use many to one in book entity
    /*
    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL)
  	private Set<Book> books;

     */

    //many to many mapping
   /* @ManyToMany(cascade = CascadeType.ALL)//cascading effect delete/save them at same time save viceverca
    @JoinTable(
            name="authors_books", joinColumns = @JoinColumn(name = "authorid"),
            inverseJoinColumns = @JoinColumn(name = "bookid")
            )*/

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "authors_books",
            joinColumns = {
                    @JoinColumn(name = "author_id",referencedColumnName = "author_id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "book_id" ,referencedColumnName = "book_id")
            }
    )
    private Set<Book> book;


    public Set<Book> getBook() {
        return book;
    }

    public void setBook(Set<Book> book) {
        this.book = book;
    }

    @Embedded
    private Subject subject;

    @Embedded
    private Address address;

    @Column(name = "subject")
    @ElementCollection(targetClass = Subject.class)
    @JoinColumn(name = "subject")
    private List<Subject> subjectlist =new ArrayList<>();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public String getAuthorname() {
        return authorname;
    }

    public void setAuthorname(String authorname) {
        this.authorname = authorname;
    }




    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }



    public List<Subject> getSubjectlist() {
        return subjectlist;
    }
    public void setSubjectlist(List<Subject> subjectlist) {
        this.subjectlist = subjectlist;
    }

    /*

  //for one to one mapping
  public Book getBook() {
        return book;
    }

    /*
    public void setBook(Book book) {
        this.book = book;
    }



    //for one to many
    public Set<Book> getBooks() {
        return books;
    }
    public void setBooks(Set<Book> books) {
        this.books = books;
    }
*/

}
