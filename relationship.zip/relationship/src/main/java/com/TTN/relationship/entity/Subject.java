package com.TTN.relationship.entity;

import javax.persistence.Embeddable;

@Embeddable
public class Subject {

    private String subject;


    private Subject()
    {

    }

    public Subject(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }


}